def Parse(line):
    str_line = str(line)
    parsed_line = str_line.replace("b'01A+00", '')
    parsed_line_cut = parsed_line[:-3]
    final=parsed_line_cut.lstrip("0")
    return final

