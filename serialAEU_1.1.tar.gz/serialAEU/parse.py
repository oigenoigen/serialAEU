def Parse(line):
    str_line=line.decode('utf-8')
    cutted_line_l=str_line.replace("01A+00",'')
    cutted_line_r=cutted_line_l[:-1]#looks like \r is one symbol
    final=cutted_line_r.lstrip("0")
    return final