import serial
from serial.tools import list_ports
import parse
from evdev import UInput, ecodes as e


ports = list(list_ports.comports())
# return the port if 'USB' is in the description
for port_num, description, address in ports:
    if 'USB' in description:
        print("Found port %s "%port_num)
        serPort=port_num

ser=serial.Serial(serPort, timeout=1)
print("Connected to %s"%ser.portstr)


while True:
    line=ser.readline()
    parsed_line = parse.Parse(line)
    if len(parsed_line)>1:#don`t ask, it has to be one

        ui = UInput()

        for i in parsed_line:
            if i == '.':
                key = 'KEY_DOT'
            else:
                key = 'KEY_%s' % i

            k = e.ecodes[key]
            # what is EV_KEY?
            ui.write(e.EV_KEY, k, 1)
            ui.write(e.EV_KEY, k, 0)

        ui.syn()

        ui.close()



