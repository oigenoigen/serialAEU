import serial
from serial.tools import list_ports
import parse
import typeLinux



ports = list(list_ports.comports())
# return the port if 'USB' is in the description
for port_num, description, address in ports:
    if 'USB' in description:
        print("Found port %s "%port_num)
        serPort=port_num
    else:
        print("Cannot find any port")

ser=serial.Serial(serPort, timeout=1)
print("Connected to %s"%ser.portstr)


while True:
    line=ser.readline()
    parsed_line = parse.Parse(line)
    if len(parsed_line)>1:#don`t ask, it has to be one

           typeLinux.type(parsed_line)




