import win32api
import win32con
import time

def type(parsed_line):
    for i in parsed_line:
        if i == ".":
            key=190
        else:
            key=ord(i)
        win32api.keybd_event(key,0,0,0)
        win32api.keybd_event(key, 0, win32con.KEYEVENTF_KEYUP,0)