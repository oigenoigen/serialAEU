from evdev import UInput, ecodes as e

def type(parsed_line):
    ui = UInput()

    for i in parsed_line:
        if i == '.':
            key = 'KEY_DOT'
        else:
            key = 'KEY_%s' % i

        k = e.ecodes[key]
        # what is EV_KEY?
        ui.write(e.EV_KEY, k, 1)
        ui.write(e.EV_KEY, k, 0)

    ui.syn()

    ui.close()