from evdev import UInput, ecodes as e
ui=UInput()
value='456.890'

for i in value:
     if i=='.':
          key='KEY_DOT'
     else:
          key='KEY_%s'%i

     k=e.ecodes[key]
     #what is EV_KEY?
     ui.write(e.EV_KEY, k, 1)
     ui.write(e.EV_KEY, k, 0)


ui.syn()

ui.close()


